<?php
/**
 * Plugin Name:    Innovation Core
 * Plugin URI:     https:// themeforest.net/user/theme-ruby/
 * Description:    features for Innovation, this is required plugin (important) for this theme.
 * Version:        1.3
 * Text Domain:    innovation-core
 * Domain Path:    /languages/
 * Author:         Theme-Ruby
 * Author URI:     https:// themeforest.net/user/theme-ruby/
 * @package        innovation-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'INNOVATION_PLUGIN_VERSION', '1.3' );
define( 'INNOVATION_CORE_URL', plugin_dir_url( __FILE__ ) );
define( 'INNOVATION_CORE_PATH', plugin_dir_path( __FILE__ ) );

// load translate
if ( ! function_exists( 'innovation_language_load' ) ) {
	function innovation_language_load() {
		load_plugin_textdomain( 'innovation-core', false, INNOVATION_CORE_PATH . 'languages/' );
	}
}

add_action( 'init', 'innovation_language_load' );

if ( ! function_exists( 'is_plugin_active' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

if ( ! is_plugin_active( 'meta-box/meta-box.php' ) ) {
	require_once INNOVATION_CORE_PATH . 'lib/meta-box/meta-box.php';
}

if ( ! is_plugin_active( 'redux-framework/redux-framework.php' ) ) {
	require_once INNOVATION_CORE_PATH . 'lib/redux-framework/framework.php';
}

require_once INNOVATION_CORE_PATH . 'lib/taxonomy-meta.php';
require_once INNOVATION_CORE_PATH . 'includes/redux.php';
require_once INNOVATION_CORE_PATH . 'includes/social.php';
require_once INNOVATION_CORE_PATH . 'includes/share.php';
require_once INNOVATION_CORE_PATH . 'includes/like.php';
require_once INNOVATION_CORE_PATH . 'includes/shortcodes.php';


// enqueue script
if ( ! function_exists( 'innovation_core_enqueue_scripts' ) ) {
	function innovation_core_enqueue_scripts() {
		wp_enqueue_style( 'innovation_core_style', INNOVATION_CORE_URL . 'assets/style.css', array(), INNOVATION_PLUGIN_VERSION, 'all' );
		wp_enqueue_script( 'innovation_core_script', INNOVATION_CORE_URL . 'assets/script.js', array( 'jquery' ), INNOVATION_PLUGIN_VERSION, true );
	}

	add_action( 'wp_enqueue_scripts', 'innovation_core_enqueue_scripts', 1 );
}


/** composer meta */
add_action( 'add_meta_boxes', 'innovation_register_composer_meta', 0 );

if ( ! function_exists( 'innovation_register_composer_meta' ) ) {
	function innovation_register_composer_meta() {
		$section = array(
			'title'      => esc_html__( 'RUBY COMPOSER', 'innovation-core' ),
			'context'    => 'normal',
			'post_types' => array( 'page' ),
			'priority'   => 'high',
		);
		add_meta_box( 'rbc-global-meta', $section['title'], 'innovation_render_global_panel', $section['post_types'], $section['context'], $section['priority'], $section );
	}
}

if ( ! function_exists( 'innovation_render_global_panel' ) ) {
	function innovation_render_global_panel() {
		wp_nonce_field( basename( __FILE__ ), 'rbc_meta_nonce' );
	}
}


// load widget
require_once( 'widgets/ruby_post_widget.php' );
require_once( 'widgets/ruby_footer_instagram_widget.php' );
require_once( 'widgets/ruby_fb_widget.php' );
require_once( 'widgets/ruby_ads_widget.php' );
require_once( 'widgets/ruby_youtube_widget.php' );
require_once( 'widgets/ruby_twitter_widget.php' );
require_once( 'widgets/ruby_social_bar_widget.php' );
require_once( 'widgets/ruby_sb_instagram_widget.php' );
require_once( 'widgets/ruby_flickr_widget.php' );
require_once( 'widgets/ruby_sb_social_counter_widget.php' );
require_once( 'widgets/ruby_footer_social_counter_widget.php' );
require_once( 'widgets/ruby_about_widget.php' );
require_once( 'widgets/ruby_banner_widget.php' );

