<?php
// No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * remove demo link
 */
if ( ! function_exists( 'innovation_ruby_redux_remove_demo_link' ) ) {
	function innovation_ruby_redux_remove_demo_link() {
		if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
			remove_filter( 'plugin_row_meta', array(
				ReduxFrameworkPlugin::get_instance(),
				'plugin_metalinks'
			), null, 2 );
		}
		if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
			remove_action( 'admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );
		}
	}

	add_action( 'init', 'innovation_ruby_redux_remove_demo_link', 1 );
}


if ( ! function_exists( 'innovation_ruby_get_option' ) ) {
	function innovation_ruby_get_option( $option_name ) {
		if ( empty( $GLOBALS['innovation_ruby_theme_options'][ $option_name ] ) ) {
			return false;
		} else {
			return $GLOBALS['innovation_ruby_theme_options'][ $option_name ];
		}
	}
}